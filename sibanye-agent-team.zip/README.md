# Sibanye Engineering website: agent team

15 Claude Code subagents plus project context to build the SES website per the Analytical Sigma proposal.

Install: copy `.claude/`, `CLAUDE.md`, `docs/` and `PROMPTS.md` into the website repo root. Add SES source material to docs/00-brief/. Start with the kickoff prompt in PROMPTS.md.

| Agent | Role | Model |
|---|---|---|
| sibanye-lead | Orchestrator, scope, gates | opus |
| discovery-analyst | Audit, fact base, requirements | sonnet |
| ux-architect | Sitemap, flows, wireframes | sonnet |
| ui-designer | Design system and prototypes | sonnet |
| content-strategist | Copy and case studies | sonnet |
| fact-checker | Claims register, release veto on content | sonnet |
| solutions-architect | Stack, content model, ADRs | opus |
| frontend-engineer | Responsive build | sonnet |
| backend-engineer | Enquiry system, email, analytics | sonnet |
| seo-specialist | Foundational SEO | sonnet |
| security-engineer | Threat model, testing, sign-off | opus |
| performance-a11y-engineer | Core Web Vitals, WCAG 2.2 AA | sonnet |
| qa-engineer | Test plan, Playwright, defects | sonnet |
| devops-engineer | CI/CD, DNS/SSL, deploy, hosting care | sonnet |
| handover-writer | Guides, runbook, acceptance pack | sonnet |

Models are suggestions; edit the `model:` line in any agent file (or use `inherit`).
