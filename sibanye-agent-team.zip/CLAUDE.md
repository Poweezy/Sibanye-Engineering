# Project: Sibanye Engineering Solutions (SES) – Corporate Website

Built by **Analytical Sigma (Pty) Ltd** for Sibanye Engineering Solutions. Proposal dated 6 Oct 2026, valid 30 days.
Commercial: E9,500 once-off build (50/30/20), E2,500/yr managed hosting & care, 90 days post-launch support, 3–4 week timeline.
Old site (reference for content and feel): https://appsystemsz.com/sibanyeengineering/index.php
Source of truth for content: the company capability statement (2026) in /docs/00-brief/ plus the old site.

## Who SES is
Multidisciplinary engineering advisory and project-management practice, Eswatini and Southern Africa.
Mission: cutting-edge, innovative solutions creating shared value. Vision: internationally respected engineering advisory firm offering sustainable solutions.
Position the firm as a credible advisory/PM practice, not an online brochure and not a generic construction template.
Themes: Engineering Excellence, Infrastructure Impact, Professional Credibility, Sustainable Growth.

## Scope (in) – 24 deliverables
Discovery, IA, UX/UI, responsive build, Home, About, Leadership, Services, Market sectors, Project portfolio + case-study layout, Capabilities, Clients/partners, Contact, Project enquiry form, Capability statement download, WhatsApp integration, foundational SEO, performance, security configuration, analytics, browser/device testing, deployment, post-launch support.
Services: Civil Engineering; Water & Sanitation; Transportation; Energy; Structural Engineering; Mining Engineering; Project & Programme Management; Industrial & Commercial Buildings.
Market sectors: Water & Sanitation, Energy, Transportation, Mining, Infrastructure, Structures, Industrial & Commercial, Healthcare, Agriculture.
Featured projects (from capability statement): Mkhondvo-Ngwavuma Water Augmentation Programme; Manzini Region Sustainable Water Supply; Ridgeview Township Roads; Sicholo Street drainage works; MR3 pedestrian bridges; Unifoods Factory Shell; Buy Cash Warehouse; National Healthcare Waste Facility; Emandla Solar PV Plant; Nsoko Solar PV Project; Lavumisa Border Project.
Approach lifecycle (7 steps, a genuine sequence): Understand, Assess, Engineer, Plan, Deliver, Assure, Close.
Hero direction: "Engineering Infrastructure. Enabling Sustainable Progress." CTAs: "Discuss Your Project" (primary), "Explore Our Capabilities" (secondary).
Contact: Suite NC202/203C, Nedbank Centre, Swazi Plaza, cnr Sozisa & Dr Sishayi Road, Mbabane, Eswatini. Tel +268 2404 5512, +268 7802 4964. Also a South African presence in Bryanston, Sandton.

## Scope (out) – do NOT build unless the lead records a signed change request
AI website assistant, project search/filter, careers portal, engineering-insights knowledge centre. Architecture must not block them later (clean content model, routes, components).
Multi-language, e-commerce, user accounts, client portal.

## Hard rules for every agent
1. **No unverified claims.** Project values, qualifications, registrations, client relationships, logos and statistics are published only if traceable to the capability statement, the old site or written SES approval. Anything else is a placeholder marked `[CONFIRM WITH SES]` and logged in docs/content-open-items.md.
2. Client logos, leadership photos and project photos need SES permission; use clearly marked placeholders until supplied. Never invent testimonials, awards or statistics.
3. English only. Currency in Emalangeni (E). Spelling: British.
4. Design must avoid a generic construction-template look: precision, engineering, infrastructure, sustainability, confidence.
5. Quality floor: responsive (mobile first), WCAG 2.2 AA, Lighthouse >= 90 on Performance/Accessibility/Best Practices/SEO, no secrets in the repo, HTTPS only.
6. Every agent writes its output to the path named in its file and appends a dated entry to docs/DECISIONS.md for any decision that affects others.
7. Stay in your lane. If you need a decision from another role, write it in docs/HANDOFFS.md addressed to that agent and tell the lead.
8. Be concise. Prefer small, reviewable changes. Never mark work done without evidence (command output, screenshot, test result).

## Recommended default stack (solutions-architect confirms or overrides in docs/05-architecture.md)
Astro + TypeScript + Tailwind CSS, content stored as typed Markdown/JSON collections (projects, services, sectors, leadership, clients) so a CMS can be added later; minimal JS; static output; one small server-side endpoint for the enquiry form; Plausible or GA4 analytics behind a consent-aware loader.

## Repository layout
/docs (00-brief ... 10-handover, DECISIONS.md, HANDOFFS.md, content-open-items.md) · /src · /public · /tests · /scripts
