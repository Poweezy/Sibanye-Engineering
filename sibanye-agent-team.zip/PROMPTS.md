# Prompts to run the Sibanye website build (Claude Code)

## 0. Setup
1. Copy this folder's contents into a new repo. Put the SES capability statement PDF, SES logo and brand assets, and the signed proposal in docs/00-brief/.
2. Open the repo in Claude Code. Run `/agents` to confirm the 15 agents load (or restart the session).

## 1. Kickoff (paste as your first message)
Use the sibanye-lead agent. Read CLAUDE.md and everything in docs/00-brief/. We are building the Sibanye Engineering Solutions corporate website exactly per the proposal dated 6 October 2026. Produce the delivery plan for the 7 phases with agents assigned, parallel work identified, exit criteria per phase from docs/GATES.md, and the first 48 hours of tasks. Start Phase 1 by delegating: discovery-analyst (audit old site and capability statement, fact base, requirements), content-strategist (content audit and page inventory), and solutions-architect (stack, content model, ADRs) in parallel. Report status in the format defined in your agent file and stop at Gate 1 for my approval.

## 2. Phase 2 – Design
Use sibanye-lead. Gate 1 is approved. Run Phase 2: ux-architect delivers sitemap, navigation, wireframes and flows; then ui-designer produces the design plan, reviews it against the brief for genericness, and builds the token file and prototypes for Home, a service page, a project case study and the enquiry form; content-strategist writes the real copy those pages need; seo-specialist supplies keyword and URL plan. Show me the design plan and screenshots before Gate 2.

## 3. Phase 3 – Build
Use sibanye-lead. Gate 2 is approved. Run Phase 3: solutions-architect scaffolds the repo; security-engineer writes the threat model first; frontend-engineer builds components and templates from the design system; backend-engineer builds the enquiry endpoint, email routing and analytics; devops-engineer sets up CI/CD, staging and scans; performance-a11y-engineer sets budgets and checks every template. Work in small commits. Report evidence (build, lint, tests, Lighthouse) at Gate 3.

## 4. Phase 4 – Content integration
Use sibanye-lead. Run Phase 4: content-strategist finalises copy and project case studies from approved sources only; frontend-engineer integrates; fact-checker produces the claims register and removes or flags every unsupported claim. List all items still needed from SES.

## 5. Phase 5 – QA and hardening
Use sibanye-lead. Run Phase 5 in parallel: qa-engineer (test plan, Playwright, cross-browser and device passes), performance-a11y-engineer (Lighthouse and WCAG 2.2 AA), security-engineer (scans, header and form abuse testing, go/no-go), seo-specialist (verify SEO checklist). Route defects to the right engineer, retest, and give me a release-candidate report.

## 6. Phase 6–7 – Launch and handover
Use sibanye-lead. Gate 5 is approved and SES has approved the content. devops-engineer prepares and executes the go-live runbook only after I give written go; fact-checker does the final claims sweep; then handover-writer produces the owner's guide, runbook, support policy and acceptance pack.

## Handy one-off prompts
- "Use ui-designer to critique the current Home page against the design plan and list the three highest-impact fixes."
- "Use security-engineer to review the diff on this branch before merge."
- "Use fact-checker to scan the site for any value, qualification or client name not in the claims register."
- "Use sibanye-lead to assess this client request as a change request with effort and timeline impact."
