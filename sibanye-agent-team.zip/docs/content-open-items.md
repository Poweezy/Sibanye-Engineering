# Content open items (client dependencies)

| Item | Needed from SES | Owner | Status |
|---|---|---|---|
| Final company wording | SES | | open |
| Current, leadership and project photographs | SES | | open |
| Logo and brand assets | SES | | open |
| Approved client logos and permissions | SES | | open |
| Final project information and values | SES | | open |
| Domain and hosting access | SES | | open |
| Designated enquiry contact email | SES | | open |
