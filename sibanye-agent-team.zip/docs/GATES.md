# Phase gates (sibanye-lead ticks only with evidence)

## Gate 1 – Discovery & Planning (2–3 days)
- [ ] Fact base and requirements baseline approved
- [ ] Sitemap, content model and stack decided (ADR logged)
- [ ] Open items sent to SES

## Gate 2 – UX/UI Design (3–5 days)
- [ ] Design plan reviewed against the "not generic" test
- [ ] Tokens, components and key page prototypes (Home, service, case study, enquiry)
- [ ] Contrast and focus checked; SES design approval recorded

## Gate 3 – Development (7–10 days)
- [ ] All templates built; build, lint, type-check pass
- [ ] Enquiry endpoint works on staging; threat model controls in place
- [ ] CI with scans running

## Gate 4 – Content Integration (3–4 days)
- [ ] All pages populated; claims register has no Unsupported items
- [ ] Placeholders listed; SES content approval recorded

## Gate 5 – Testing & QA (2–3 days)
- [ ] QA report: no open critical/high defects
- [ ] Security report: go
- [ ] Lighthouse >= 90 x4; WCAG 2.2 AA audit clean of blockers
- [ ] SEO checklist verified

## Gate 6 – Deployment (1 day)
- [ ] Final SES approval; DNS, SSL, email deliverability, analytics, 301s verified
- [ ] Backups and monitoring live

## Gate 7 – Handover
- [ ] Owner's guide, runbook, support policy, acceptance pack delivered
